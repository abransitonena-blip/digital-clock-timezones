// App web de LetreroLab AP-0.2: se sirve desde el propio módulo (http://<nombre>.local o la IP).
#pragma once
const char PAGINA[] PROGMEM = R"HTML(<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>LetreroLab</title>
<style>
:root{--f:#0f1419;--t:#18202a;--b:#243041;--x:#e8eef5;--s:#8fa3b8;--a:#22c55e;--r:#ef4444;--y:#f59e0b}
*{box-sizing:border-box}body{margin:0;background:var(--f);color:var(--x);font:15px system-ui,sans-serif}
header{display:flex;align-items:center;gap:10px;padding:12px 16px;background:var(--t);border-bottom:1px solid var(--b)}
header b{font-size:17px}header small{color:var(--s);margin-left:auto;text-align:right}
nav{display:flex;background:var(--t);position:sticky;top:0;z-index:2}nav button{flex:1;padding:12px 4px;background:none;border:0;
color:var(--s);font:inherit;border-bottom:2px solid transparent}nav button.on{color:var(--x);border-color:var(--a)}
main{max-width:640px;margin:auto;padding:12px 16px 40px}section{display:none}section.on{display:block}
.card{background:var(--t);border:1px solid var(--b);border-radius:12px;padding:14px;margin:12px 0}
.card h3{margin:0 0 10px;font-size:14px;color:var(--s);font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:8px 0}.row>label{min-width:90px;color:var(--s)}
button.b{background:var(--b);color:var(--x);border:0;border-radius:9px;padding:10px 12px;font:inherit;cursor:pointer}
button.b.on{background:var(--a);color:#04210f;font-weight:600}button.b.r{background:var(--r)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:8px}
.big{width:100%;padding:16px;font-size:18px}input,select{background:var(--f);color:var(--x);border:1px solid var(--b);
border-radius:8px;padding:9px;font:inherit;min-width:0}input[type=range]{flex:1;padding:0}input[type=color]{width:52px;height:40px;padding:2px}
.dias label{display:inline-flex;align-items:center;gap:2px;margin-right:6px;color:var(--s)}.dias input{margin:0}
.muted{color:var(--s);font-size:13px}.dev{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--b)}
.dev span{flex:1}.met{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;text-align:center}.met b{display:block;font-size:22px}
.met span{color:var(--s);font-size:12px}.alerta{background:#3b1414;border:1px solid var(--r);color:#fecaca}
.barra{height:8px;border-radius:99px;background:var(--b);overflow:hidden;margin-top:6px}.barra i{display:block;height:100%;background:var(--a)}
.pill{font-size:12px;padding:2px 8px;border-radius:99px;background:var(--b);color:var(--s)}
#msg{position:fixed;left:50%;bottom:16px;transform:translateX(-50%);background:var(--b);padding:8px 14px;border-radius:9px;display:none}
</style></head><body>
<header><b>LetreroLab</b><span class="pill" id="nom">...</span><small id="hora"></small></header>
<nav><button data-t="ctl" class="on">Control</button><button data-t="hor">Horarios</button><button data-t="casa">Casa</button><button data-t="aj">Ajustes</button></nav>
<main>
<section id="ctl" class="on">
 <div class="card alerta" id="falla" style="display:none"><b>Protección activada: <span id="fn"></span></b>
  <p class="muted" style="color:#fecaca" id="fd"></p><button class="b r" id="fok">Restablecer</button></div>
 <button class="b big" id="pw">...</button>
 <div class="card" id="cons" style="display:none"><h3>Consumo</h3><div class="met">
  <div><b id="mw">0</b><span>watts</span></div><div><b id="ma">0</b><span>amperes</span></div><div><b id="mv">0</b><span>volts</span></div>
  <div><b id="mt">--</b><span>°C tarjeta</span></div><div><b id="mh">0</b><span>kWh hoy</span></div><div><b id="mk">0</b><span>kWh total</span></div></div>
  <div class="barra"><i id="mbar" style="width:0"></i></div><p class="muted" id="mlim"></p></div>
 <div class="card"><h3>Modo</h3><div class="grid" id="modos"></div>
  <div class="row"><label>Velocidad</label><input type="range" min="0" max="9" id="vel"></div>
  <div class="row"><label>Brillo</label><input type="range" min="5" max="100" id="bri"><span id="briv"></span></div></div>
 <div class="card"><h3>Color (modos Color y Vela)</h3>
  <div class="row"><input type="color" id="rgb"><label style="min-width:auto">Blanco</label><input type="range" min="0" max="255" id="w"></div>
  <div class="row"><label>Canales</label><select id="ch"><option value="1">1</option><option value="2">2</option>
  <option value="3">3 (flechas / RGB)</option><option value="4">4 (RGBW)</option></select></div></div>
 <div class="card"><h3>Focos (relevador)</h3><div class="row"><button class="b" id="foco">...</button>
  <span class="muted">Contacto seco 10 A para focos normales de 127/240 V</span></div></div>
 <div class="card"><h3>Ahorro y sensor de luz</h3>
  <div class="row"><button class="b" id="eco">Ahorro</button><button class="b" id="ldr">Solo de noche</button></div>
  <div class="row"><label>Umbral</label><input type="range" min="50" max="1000" id="umb"><span class="muted" id="lv"></span></div></div>
 <div class="card"><h3>Escenas</h3><div class="row" id="esc"></div><p class="muted">Toque = cargar. Mantener = guardar la actual.</p></div>
</section>

<section id="hor">
 <div class="card"><h3>Hora del equipo</h3><div class="row"><span id="hora2" style="flex:1"></span>
  <button class="b" id="usarHora">Usar la hora del teléfono</button></div>
  <p class="muted">Con internet se ajusta sola (NTP). Con reloj DS3231 se conserva aunque se vaya la luz.</p></div>
 <div class="card"><h3>Ventana diaria</h3><div class="row"><label>Encender</label><input type="time" id="von">
  <label style="min-width:auto">Apagar</label><input type="time" id="voff"></div>
  <div class="row"><button class="b" id="vok">Guardar</button><button class="b" id="vno">Sin ventana</button></div>
  <p class="muted">Fuera de la ventana todo queda apagado. Puede cruzar la medianoche (19:00 a 02:00).</p></div>
 <div class="card"><h3>Horarios (8)</h3><div id="progs"></div></div>
</section>

<section id="casa">
 <div class="card"><h3>Toda la casa</h3>
  <div class="row"><button class="b big" style="flex:1" data-g="@* P1">Encender todo</button>
  <button class="b big r" style="flex:1" data-g="@* P0">Apagar todo</button></div>
  <div class="row"><button class="b" data-g="@* X1">Focos: encender todos</button><button class="b" data-g="@* X0">Focos: apagar todos</button></div></div>
 <div class="card"><h3>Mi grupo: <span id="gnom"></span></h3>
  <div class="row"><button class="b" id="gon">Encender grupo</button><button class="b" id="goff">Apagar grupo</button></div></div>
 <div class="card"><h3>Equipos en la red</h3><div id="devs" class="muted">Buscando...</div></div>
</section>

<section id="aj">
 <div class="card"><h3>Equipo</h3>
  <div class="row"><label>Nombre</label><input id="fnom" placeholder="sala"><button class="b" id="snom">Guardar</button></div>
  <div class="row"><label>Grupo</label><input id="fgr" placeholder="planta-alta"><button class="b" id="sgr">Guardar</button></div>
  <p class="muted">Solo letras, números y guiones. El nombre también da la dirección http://nombre.local</p></div>
 <div class="card"><h3>Wi-Fi</h3>
  <div class="row"><label>Red</label><select id="redes" style="flex:1"><option value="">(buscar...)</option></select><button class="b" id="buscar">Buscar</button></div>
  <div class="row"><label>Clave</label><input id="wcl" type="password" style="flex:1"></div>
  <div class="row"><button class="b on" id="wok">Conectar</button><span class="muted" id="wst"></span></div></div>
 <div class="card"><h3>Zona horaria</h3><div class="row"><select id="tz" style="flex:1"></select><button class="b" id="tzok">Guardar</button></div></div>
 <div class="card"><h3>Control fuera de casa (MQTT)</h3>
  <div class="row"><label>Servidor</label><input id="mq" style="flex:1" placeholder="mqtts://xxxx.hivemq.cloud:8883"></div>
  <div class="row"><label>Usuario</label><input id="mqu" style="flex:1"></div>
  <div class="row"><label>Clave</label><input id="mqc" type="password" style="flex:1"></div>
  <div class="row"><button class="b" id="mqok">Guardar</button><button class="b" id="mqno">Quitar</button><span class="muted" id="mqst"></span></div>
  <p class="muted">Temas: letrerolab/&lt;nombre&gt;/cmd (órdenes), /estado (respuesta), letrerolab/todos/cmd, letrerolab/grupo/&lt;grupo&gt;/cmd</p></div>
 <div class="card"><h3>Protección de potencia</h3>
  <div class="row"><label>Límite</label><input type="range" min="1" max="25" id="lim"><span id="limv"></span></div>
  <p class="muted">Corriente total máxima (todas las salidas). Al pasarla se apagan las salidas y reintenta a los 10 s;
  tras 3 disparos en 5 min queda apagado hasta "Restablecer". Usa un fusible del mismo valor o mayor.</p>
  <div class="row"><button class="b" id="ureset">Reiniciar contador de kWh</button></div></div>
 <div class="card"><h3>Seguridad</h3><div class="row"><label>Clave app</label><input id="kc" type="password" style="flex:1">
  <button class="b" id="kok">Guardar</button></div><p class="muted">Usuario: letrerolab. Vacía = sin clave (no recomendado).</p></div>
 <div class="card"><h3>Actualizar programa</h3><div class="row"><input type="file" id="bin" accept=".bin" style="flex:1">
  <button class="b" id="ota">Subir</button></div><p class="muted" id="otast"></p></div>
 <div class="card"><h3>Información</h3><p class="muted" id="info"></p><button class="b r" id="reini">Reiniciar</button></div>
</section>
</main><div id="msg"></div>
<script>
const $=i=>document.getElementById(i),MOD=["Fijo","Secuencia","Parpadeo","Respirar","Sec. suave","Alternado","Color","Arcoíris","Flash","Vela"],
DIAS="DLMMJVS",DN=["dom","lun","mar","mié","jue","vie","sáb"],ACC=["Apagar todo","Encender todo","Focos","Escena","Brillo"];let E={},cambiando=0;
const TZ=[["CST6","México centro (CDMX, GDL, MTY)"],["EST5","Cancún / Quintana Roo"],["MST7","Sonora / Mazatlán"],
["PST8PDT,M3.2.0,M11.1.0","Tijuana"],["CST6CDT,M3.2.0,M11.1.0","Frontera norte / Chicago"],["EST5EDT,M3.2.0,M11.1.0","Nueva York"],
["PST8PDT,M3.2.0,M11.1.0","Los Ángeles"],["COT5","Colombia"],["PET5","Perú"],["ECT5","Ecuador"],["VET4","Venezuela"],
["<-03>3","Argentina / Uruguay"],["<-04>4<-03>,M9.1.6/24,M4.1.6/24","Chile"],["CST6","Centroamérica"],
["CET-1CEST,M3.5.0,M10.5.0/3","España"],["UTC0","UTC"]];
function msg(t){const m=$("msg");m.textContent=t;m.style.display="block";clearTimeout(msg.t);msg.t=setTimeout(()=>m.style.display="none",2200)}
async function api(c){try{const r=await fetch("/api"+(c?"?c="+encodeURIComponent(c):""));E=await r.json();pinta()}catch(e){msg("Sin conexión")}}
const hm=m=>m<0?"--:--":String(m/60|0).padStart(2,"0")+":"+String(m%60).padStart(2,"0");
function pinta(){
 $("nom").textContent=E.nom;$("gnom").textContent=E.g;$("hora").textContent=E.t>=0?DN[E.wd]+" "+hm(E.t):"sin hora";
 $("hora2").textContent=E.t>=0?"Ahora: "+hm(E.t)+(E.rtc?" (con DS3231)":""):"Sin hora todavía";
 const pw=$("pw");pw.textContent=E.p?"Encendido":"Apagado";pw.className="b big"+(E.p?" on":"");
 document.querySelectorAll("#modos button").forEach((b,i)=>b.className="b"+(i==E.m?" on":""));
 if(!cambiando){$("vel").value=E.s;$("bri").value=E.b;$("umb").value=E.u;$("ch").value=E.ch;$("w").value=E.c[3];
  $("rgb").value="#"+E.c.slice(0,3).map(v=>v.toString(16).padStart(2,"0")).join("")}
 $("briv").textContent=E.b+"%";$("lv").textContent="luz actual "+E.lv;
 $("foco").textContent=E.x?"Focos encendidos":"Focos apagados";$("foco").className="b"+(E.x?" on":"");
 $("eco").className="b"+(E.e?" on":"");$("ldr").className="b"+(E.l?" on":"");
 if(document.activeElement.tagName!="INPUT"){$("fnom").value=E.nom;$("fgr").value=E.g;$("tz").value=E.tz;
  if(E.on>=0){$("von").value=hm(E.on);$("voff").value=hm(E.off)}}
 $("mqst").textContent=["sin MQTT","conectando...","conectado"][E.mq];
 $("wst").textContent=E.ap?"Modo configuración":(E.red?"Conectado a "+E.red+" ("+E.rssi+" dBm)":"");
 $("info").textContent=E.v+" · IP "+E.ip+" · http://"+E.nom+".local"+(E.k?" · con clave":" · SIN clave");
 if(!document.querySelector("#progs :focus"))progs();
 $("cons").style.display=E.med?"block":"none";$("falla").style.display=E.f?"block":"none";
 $("fn").textContent=E.fn;$("fd").textContent=`Medido: ${E.vin} V, ${E.i} A, ${E.tc??"--"} °C. `+(E.f==1?"Revisa cortos o la carga total.":E.f==2?"Mejora la ventilación; vuelve sola al enfriarse.":"Revisa la fuente (máx. 30 V).");
 $("mw").textContent=Math.round(E.w);$("ma").textContent=E.i.toFixed(1);$("mv").textContent=E.vin.toFixed(1);
 $("mt").textContent=E.tc==null?"--":E.tc.toFixed(0);$("mh").textContent=E.hoy.toFixed(2);$("mk").textContent=E.kwh.toFixed(1);
 $("mbar").style.width=Math.min(100,E.i/E.lim*100)+"%";$("mbar").style.background=E.i>E.lim*.85?"var(--r)":E.i>E.lim*.6?"var(--y)":"var(--a)";
 $("mlim").textContent=`Límite ${E.lim} A`+(E.fp<100&&E.p&&!E.f?` · brillo limitado al ${E.fp}% (arranque o temperatura)`:"");
 if(!cambiando)$("lim").value=E.lim;$("limv").textContent=E.lim+" A";
}
function progs(){let h="";E.a.forEach((p,i)=>{h+=`<div class="card" style="margin:8px 0"><div class="row dias">${[...DIAS].map((d,j)=>
 `<label><input type="checkbox" data-d="${j}" ${p[1]>>j&1?"checked":""}>${d}</label>`).join("")}</div>
 <div class="row"><input type="time" value="${hm(p[2]*60+p[3])}"><select>${ACC.map((a,j)=>`<option value="${j}" ${j==p[4]?"selected":""}>${a}</option>`).join("")}</select>
 <input type="number" min="0" max="100" value="${p[5]}" style="width:70px" title="valor: focos 0/1, escena 0-3, brillo %">
 <button class="b${p[0]?" on":""}" data-i="${i}">${p[0]?"Guardado":"Guardar"}</button><button class="b" data-x="${i}">Borrar</button></div></div>`});
 $("progs").innerHTML=h;
 $("progs").querySelectorAll("[data-i]").forEach(b=>b.onclick=()=>{const c=b.closest(".card");let d=0;
  c.querySelectorAll("[data-d]").forEach(x=>{if(x.checked)d|=1<<x.dataset.d});const t=c.querySelector("[type=time]").value||"00:00";
  api(`A ${b.dataset.i} ${d||127} ${t} ${c.querySelector("select").value} ${c.querySelector("[type=number]").value||0}`);msg("Horario guardado")});
 $("progs").querySelectorAll("[data-x]").forEach(b=>b.onclick=()=>api(`A ${b.dataset.x} -`));
}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{document.querySelectorAll("nav button,section").forEach(x=>x.classList.remove("on"));
 b.classList.add("on");$(b.dataset.t).classList.add("on");if(b.dataset.t=="casa")vecinos()});
MOD.forEach((m,i)=>{const b=document.createElement("button");b.className="b";b.textContent=m;b.onclick=()=>api("M "+i);$("modos").append(b)});
for(let i=0;i<4;i++){const b=document.createElement("button");b.className="b";b.textContent="Escena "+(i+1);let t;
 b.onpointerdown=()=>t=setTimeout(()=>{t=0;api("S "+i);msg("Escena guardada")},800);b.onpointerup=()=>{if(t){clearTimeout(t);api("R "+i)}};$("esc").append(b)}
const desliza=(id,f)=>{const e=$(id);e.oninput=()=>{cambiando=1};e.onchange=()=>{cambiando=0;api(f(e.value))}};
desliza("vel",v=>"V "+v);desliza("lim",v=>"J "+v);desliza("bri",v=>"B "+v);desliza("umb",v=>"L "+E.l+" "+v);desliza("w",()=>colorCmd());
const colorCmd=()=>{const h=$("rgb").value;return`C ${parseInt(h.substr(1,2),16)} ${parseInt(h.substr(3,2),16)} ${parseInt(h.substr(5,2),16)} ${$("w").value}`};
$("rgb").onchange=()=>api(colorCmd());$("ch").onchange=()=>api("N "+$("ch").value);
$("pw").onclick=()=>api("P "+(E.p?0:1));$("foco").onclick=()=>api("X "+(E.x?0:1));
$("eco").onclick=()=>api("E "+(E.e?0:1));$("ldr").onclick=()=>api("L "+(E.l?0:1)+" "+E.u);
$("usarHora").onclick=()=>{const d=new Date(),p=n=>String(n).padStart(2,"0");
 api(`T ${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`);msg("Hora puesta")};
$("vok").onclick=()=>api(`H ${$("von").value} ${$("voff").value}`);$("vno").onclick=()=>api("H -");
document.querySelectorAll("[data-g]").forEach(b=>b.onclick=()=>{api(b.dataset.g);msg("Enviado a toda la casa")});
$("gon").onclick=()=>api(`@${E.g} P1`);$("goff").onclick=()=>api(`@${E.g} P0`);
async function vecinos(){try{const l=await(await fetch("/vecinos")).json();
 $("devs").innerHTML=l.length?l.map(v=>`<div class="dev"><span><b>${v.nom}</b> <span class="pill">${v.g}</span></span>
 <button class="b" onclick="otro('${v.ip}','P1')">On</button><button class="b" onclick="otro('${v.ip}','P0')">Off</button>
 <a class="b" style="text-decoration:none;padding:10px;color:var(--x)" href="http://${v.ip}/">Abrir</a></div>`).join(""):"No se ven otros equipos (deben estar en la misma red Wi-Fi).";
}catch(e){$("devs").textContent="Error"}}
function otro(ip,c){fetch(`http://${ip}/api?c=${c}`,{mode:"no-cors"}).then(()=>msg("Enviado"))}
TZ.forEach(([v,n])=>{const o=document.createElement("option");o.value=v;o.textContent=n;$("tz").append(o)});
$("tzok").onclick=()=>api("Z "+$("tz").value);
$("snom").onclick=()=>{api("D "+$("fnom").value);msg("Reiniciando con el nuevo nombre...")};$("sgr").onclick=()=>api("G "+$("fgr").value);
$("buscar").onclick=async()=>{$("buscar").textContent="...";try{const l=await(await fetch("/redes")).json();
 $("redes").innerHTML=l.map(r=>`<option>${r.r}</option>`).join("")}catch(e){}$("buscar").textContent="Buscar"};
$("wok").onclick=()=>{const r=$("redes").value;if(!r)return msg("Elige una red");api(`W ${r},${$("wcl").value}`);
 msg("Conectando... busca el equipo en tu red como "+E.nom+".local")};
$("mqok").onclick=()=>api(`Q ${$("mq").value},${$("mqu").value},${$("mqc").value}`);$("mqno").onclick=()=>api("Q -");
$("kok").onclick=()=>{api("K "+$("kc").value);msg("Clave guardada")};
$("fok").onclick=()=>api("F 0");$("ureset").onclick=()=>{if(confirm("¿Poner en cero los kWh?"))api("U 0")};
$("reini").onclick=()=>{if(confirm("¿Reiniciar el equipo?"))api("!")};
$("ota").onclick=async()=>{const f=$("bin").files[0];if(!f)return;const d=new FormData();d.append("f",f);$("otast").textContent="Subiendo...";
 try{$("otast").textContent=await(await fetch("/ota",{method:"POST",body:d})).text()}catch(e){$("otast").textContent="Error"}};
api();setInterval(()=>{if(!document.hidden&&!cambiando)api()},3000);
</script></body></html>)HTML";
